package com.realisticexplosions.event;

import com.realisticexplosions.RealisticExplosions;
import com.realisticexplosions.network.NetworkHandler;
import com.realisticexplosions.network.PacketExplosionEffect;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ExplosionEventHandler {

    // Расстояние, на котором ударная волна ещё действует (в блоках)
    private static final double SHOCKWAVE_RADIUS = 32.0;
    // Максимальный урон от ударной волны
    private static final float MAX_SHOCKWAVE_DAMAGE = 20.0f;
    // Скорость звука в блоках в секунду (примерно 343 м/с, 1 блок ≈ 1 метр)
    private static final double SOUND_SPEED_BLOCKS_PER_SEC = 60.0; // игровое время

    @SubscribeEvent
    public void onExplosionDetonate(ExplosionEvent.Detonate event) {
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        Explosion explosion = event.getExplosion();
        Vec3 center = explosion.getPosition();
        float power = getExplosionRadius(explosion);

        // Нормализованный размер взрыва (1.0 = стандартный TNT)
        float normalizedPower = power / 4.0f;

        // Отправляем всем игрокам в зоне пакет с эффектами
        for (ServerPlayer player : serverLevel.players()) {
            double dist = player.position().distanceTo(center);
            if (dist > SHOCKWAVE_RADIUS * 2) continue;

            // Задержка звука по расстоянию (в тиках, 1 тик = 0.05 сек)
            int soundDelayTicks = (int)(dist / SOUND_SPEED_BLOCKS_PER_SEC * 20);

            // Отправляем пакет клиенту
            NetworkHandler.sendToPlayer(
                new PacketExplosionEffect(center, power, normalizedPower, (float)dist, soundDelayTicks),
                player
            );
        }

        // Серверная часть: ударная волна — урон и отброс
        applyShockwave(serverLevel, center, power, normalizedPower);
    }

    private float getExplosionRadius(Explosion explosion) {
        try {
            java.lang.reflect.Field f = Explosion.class.getDeclaredField("radius");
            f.setAccessible(true);
            return f.getFloat(explosion);
        } catch (Exception e) {
            return 4.0f; // стандартный TNT
        }
    }

    private void applyShockwave(ServerLevel level, Vec3 center, float power, float normalizedPower) {
        double radius = SHOCKWAVE_RADIUS * normalizedPower;

        for (Entity entity : level.getEntities(null,
                new net.minecraft.world.phys.AABB(
                    center.x - radius, center.y - radius, center.z - radius,
                    center.x + radius, center.y + radius, center.z + radius))) {

            double dist = entity.position().distanceTo(center);
            if (dist > radius || dist < 0.1) continue;

            // Сила уменьшается с расстоянием квадратично
            double falloff = 1.0 - (dist / radius);
            falloff = falloff * falloff;

            // Отброс: направление от центра
            Vec3 dir = entity.position().subtract(center).normalize();
            double knockbackStrength = 3.0 * normalizedPower * falloff;
            entity.setDeltaMovement(
                entity.getDeltaMovement()
                    .add(dir.x * knockbackStrength, dir.y * knockbackStrength + 0.4 * falloff, dir.z * knockbackStrength)
            );
            entity.hurtMarked = true;

            // Урон
            if (entity instanceof net.minecraft.world.entity.LivingEntity living) {
                float damage = (float)(MAX_SHOCKWAVE_DAMAGE * normalizedPower * falloff);
                if (damage > 0.5f) {
                    living.hurt(level.damageSources().explosion(null), damage);
                }
            }
        }
    }
}
