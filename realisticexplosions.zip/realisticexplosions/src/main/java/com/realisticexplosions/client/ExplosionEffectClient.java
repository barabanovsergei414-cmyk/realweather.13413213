package com.realisticexplosions.client;

import com.realisticexplosions.particle.ExplosionParticles;
import com.realisticexplosions.sound.SoundRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class ExplosionEffectClient {

    public static final List<ShockwaveRing> SHOCKWAVES = new ArrayList<>();
    public static float shakePower = 0;
    public static float shakeX = 0;
    public static float shakeY = 0;
    public static float flashAlpha = 0;

    private static final List<DelayedSound> DELAYED_SOUNDS = new ArrayList<>();
    private static final Random RNG = new Random();

    public static void triggerEffect(Vec3 center, float power, float normalizedPower,
                                     float distToPlayer, int soundDelayTicks) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        // Вспышка
        float flashStrength = Math.max(0, 1.0f - distToPlayer / 48.0f);
        flashAlpha = Math.min(1.0f, normalizedPower * flashStrength * 0.85f);

        // Тряска
        float shakeStrength = normalizedPower * Math.max(0, 1.0f - distToPlayer / 30.0f);
        shakePower = Math.max(shakePower, shakeStrength * 6.0f);

        // Ударная волна
        SHOCKWAVES.add(new ShockwaveRing(center, normalizedPower));

        // Частицы
        spawnFX(mc, center, normalizedPower, power);

        // Звук с задержкой
        DELAYED_SOUNDS.add(new DelayedSound(center, normalizedPower, soundDelayTicks, false));
    }

    private static void spawnFX(Minecraft mc, Vec3 c, float np, float power) {
        // Огненный шар
        int fire = (int)(30 * np);
        for (int i = 0; i < fire; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double elev = (RNG.nextDouble() - 0.3) * Math.PI;
            double speed = (0.3 + RNG.nextDouble() * 0.5) * np;
            mc.level.addParticle(ParticleTypes.FLAME,
                c.x + (RNG.nextDouble()-0.5)*power*0.4,
                c.y + RNG.nextDouble()*power*0.3,
                c.z + (RNG.nextDouble()-0.5)*power*0.4,
                Math.cos(ang)*Math.cos(elev)*speed,
                Math.sin(elev)*speed + 0.15,
                Math.sin(ang)*Math.cos(elev)*speed);
        }

        // Дым столбом
        int smoke = (int)(70 * np);
        for (int i = 0; i < smoke; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double r = RNG.nextDouble() * power * 0.6;
            double startY = RNG.nextDouble() * power * 0.3;
            mc.level.addParticle(ExplosionParticles.EXPLOSION_SMOKE.get(),
                c.x + Math.cos(ang)*r,
                c.y + startY,
                c.z + Math.sin(ang)*r,
                Math.cos(ang)*0.05 + (RNG.nextDouble()-0.5)*0.1,
                0.15 + RNG.nextDouble()*0.25*np,
                Math.sin(ang)*0.05 + (RNG.nextDouble()-0.5)*0.1);
        }

        // Пыль
        int dust = (int)(80 * np);
        for (int i = 0; i < dust; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double speed = (0.5 + RNG.nextDouble()) * np;
            mc.level.addParticle(ExplosionParticles.EXPLOSION_DUST.get(),
                c.x + (RNG.nextDouble()-0.5)*power*0.3,
                c.y + RNG.nextDouble()*0.5,
                c.z + (RNG.nextDouble()-0.5)*power*0.3,
                Math.cos(ang)*speed,
                RNG.nextDouble()*0.4*np,
                Math.sin(ang)*speed);
        }

        // Искры
        int spark = (int)(50 * np);
        for (int i = 0; i < spark; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double elev = RNG.nextDouble() * Math.PI * 0.5;
            double speed = (1.0 + RNG.nextDouble()*2.0)*np;
            mc.level.addParticle(ExplosionParticles.EXPLOSION_SPARK.get(),
                c.x, c.y+0.5, c.z,
                Math.cos(ang)*Math.cos(elev)*speed,
                Math.sin(elev)*speed+0.3,
                Math.sin(ang)*Math.cos(elev)*speed);
        }

        // Гриб дыма (для большого взрыва)
        if (np > 0.8f) {
            int mushroom = (int)(25 * np);
            for (int i = 0; i < mushroom; i++) {
                double ang = RNG.nextDouble() * Math.PI * 2;
                double r = RNG.nextDouble() * power * 0.4;
                double h = power*0.5 + RNG.nextDouble()*power*1.5;
                mc.level.addParticle(ExplosionParticles.EXPLOSION_SMOKE.get(),
                    c.x+Math.cos(ang)*r, c.y+h, c.z+Math.sin(ang)*r,
                    (RNG.nextDouble()-0.5)*0.15, 0.05+RNG.nextDouble()*0.1,
                    (RNG.nextDouble()-0.5)*0.15);
            }
        }
    }

    public static void tick() {
        if (shakePower > 0.01f) {
            shakeX = (float)(RNG.nextGaussian() * shakePower * 0.8);
            shakeY = (float)(RNG.nextGaussian() * shakePower * 0.5);
            shakePower *= 0.72f;
            if (shakePower < 0.01f) { shakePower = 0; shakeX = 0; shakeY = 0; }
        }
        if (flashAlpha > 0.01f) {
            flashAlpha *= 0.78f;
            if (flashAlpha < 0.01f) flashAlpha = 0;
        }

        SHOCKWAVES.removeIf(r -> { r.tick(); return r.isDead(); });

        Minecraft mc = Minecraft.getInstance();
        Iterator<DelayedSound> it = DELAYED_SOUNDS.iterator();
        while (it.hasNext()) {
            DelayedSound ds = it.next();
            if (--ds.ticksLeft <= 0) {
                playSound(mc, ds);
                it.remove();
            }
        }
    }

    private static void playSound(Minecraft mc, DelayedSound ds) {
        if (mc.level == null) return;
        float vol = Math.min(8.0f, 1.5f + ds.normalizedPower * 3.0f);
        if (!ds.isEcho) {
            mc.level.playLocalSound(ds.center.x, ds.center.y, ds.center.z,
                SoundRegistry.EXPLOSION_BLAST.get(), SoundSource.BLOCKS,
                vol, 0.8f + RNG.nextFloat()*0.2f, false);
            // Планируем гул через 10 тиков
            DELAYED_SOUNDS.add(new DelayedSound(ds.center, ds.normalizedPower, 10, true));
        } else {
            mc.level.playLocalSound(ds.center.x, ds.center.y, ds.center.z,
                SoundRegistry.EXPLOSION_RUMBLE.get(), SoundSource.BLOCKS,
                vol * 0.7f, 0.5f + RNG.nextFloat()*0.15f, false);
        }
    }

    // --- Классы ---

    public static class ShockwaveRing {
        public final Vec3 center;
        public final float maxRadius;
        public float radius = 0;
        public float alpha = 1.0f;
        private int age = 0;
        private static final int LIFETIME = 30;

        public ShockwaveRing(Vec3 center, float np) {
            this.center = center;
            this.maxRadius = 4.0f + 12.0f * np;
        }
        public void tick() {
            age++;
            float t = (float)age / LIFETIME;
            radius = maxRadius * (float)Math.sqrt(t);
            alpha = (1-t)*(1-t);
        }
        public boolean isDead() { return age >= LIFETIME; }
        public float getPartialRadius(float p) {
            float t = ((float)age+p)/LIFETIME;
            return maxRadius*(float)Math.sqrt(Math.min(t,1));
        }
        public float getPartialAlpha(float p) {
            float t = ((float)age+p)/LIFETIME;
            float c = Math.min(t,1);
            return (1-c)*(1-c);
        }
    }

    static class DelayedSound {
        final Vec3 center; final float normalizedPower; int ticksLeft; final boolean isEcho;
        DelayedSound(Vec3 c, float np, int t, boolean echo) {
            center=c; normalizedPower=np; ticksLeft=t; isEcho=echo;
        }
    }
}
