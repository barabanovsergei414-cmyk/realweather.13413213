package com.realisticexplosions.sound;

import com.realisticexplosions.RealisticExplosions;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class SoundRegistry {

    public static final DeferredRegister<SoundEvent> SOUNDS =
        DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, RealisticExplosions.MODID);

    // Основной резкий хлопок взрыва
    public static final RegistryObject<SoundEvent> EXPLOSION_BLAST =
        SOUNDS.register("explosion_blast",
            () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(RealisticExplosions.MODID, "explosion_blast")));

    // Глубокий гул / эхо после взрыва
    public static final RegistryObject<SoundEvent> EXPLOSION_RUMBLE =
        SOUNDS.register("explosion_rumble",
            () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(RealisticExplosions.MODID, "explosion_rumble")));
}
