package com.realisticexplosions.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ExplosionSmokeParticle extends TextureSheetParticle {

    private final float startSize;

    private ExplosionSmokeParticle(ClientLevel level, double x, double y, double z,
                                    double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz);

        // Тёмно-серый, почти чёрный дым от ТНТ
        float gray = 0.05f + (float)(random.nextDouble() * 0.15);
        this.rCol = gray;
        this.gCol = gray;
        this.bCol = gray;
        this.alpha = 0.85f;

        this.lifetime = 80 + random.nextInt(60);
        this.startSize = 0.6f + (float)(random.nextDouble() * 1.2);
        this.quadSize = startSize;
        this.gravity = -0.005f; // почти не падает, дым поднимается

        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;

        // Плавно расширяется
        float lifeRatio = (float)this.age / this.lifetime;
        this.quadSize = startSize * (1.0f + lifeRatio * 2.5f);

        // Гаснет в конце
        if (lifeRatio > 0.4f) {
            this.alpha = 0.85f * (1.0f - (lifeRatio - 0.4f) / 0.6f);
        }

        // Физика
        this.yd += 0.002f; // небольшой подъём
        this.xd *= 0.97f;
        this.zd *= 0.97f;

        this.move(this.xd, this.yd, this.zd);

        if (this.age++ >= this.lifetime) this.remove();
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Factory(SpriteSet sprites) { this.sprites = sprites; }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                        double x, double y, double z,
                                        double vx, double vy, double vz) {
            ExplosionSmokeParticle p = new ExplosionSmokeParticle(level, x, y, z, vx, vy, vz);
            p.pickSprite(sprites);
            return p;
        }
    }
}
