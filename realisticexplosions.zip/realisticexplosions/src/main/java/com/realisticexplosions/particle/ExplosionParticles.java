package com.realisticexplosions.particle;

import com.realisticexplosions.RealisticExplosions;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ExplosionParticles {

    public static final DeferredRegister<ParticleType<?>> PARTICLE_TYPES =
        DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, RealisticExplosions.MODID);

    public static final RegistryObject<SimpleParticleType> EXPLOSION_DUST =
        PARTICLE_TYPES.register("explosion_dust", () -> new SimpleParticleType(false));

    public static final RegistryObject<SimpleParticleType> EXPLOSION_SPARK =
        PARTICLE_TYPES.register("explosion_spark", () -> new SimpleParticleType(false));

    public static final RegistryObject<SimpleParticleType> EXPLOSION_SMOKE =
        PARTICLE_TYPES.register("explosion_smoke", () -> new SimpleParticleType(false));

    public static void registerFactories() {
        Minecraft mc = Minecraft.getInstance();
        mc.particleEngine.register(EXPLOSION_DUST.get(),  ExplosionDustParticle.Factory::new);
        mc.particleEngine.register(EXPLOSION_SPARK.get(), ExplosionSparkParticle.Factory::new);
        mc.particleEngine.register(EXPLOSION_SMOKE.get(), ExplosionSmokeParticle.Factory::new);
    }
}
