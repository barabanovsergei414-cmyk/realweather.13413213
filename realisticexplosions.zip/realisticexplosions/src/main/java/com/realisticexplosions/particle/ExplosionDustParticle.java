package com.realisticexplosions.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ExplosionDustParticle extends TextureSheetParticle {

    private ExplosionDustParticle(ClientLevel level, double x, double y, double z,
                                   double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz);

        // Серо-коричневый цвет пыли
        this.rCol = 0.55f + (float)(random.nextDouble() * 0.2);
        this.gCol = 0.45f + (float)(random.nextDouble() * 0.15);
        this.bCol = 0.30f + (float)(random.nextDouble() * 0.1);
        this.alpha = 0.9f;

        this.lifetime = 40 + random.nextInt(30);
        this.quadSize = 0.3f + (float)(random.nextDouble() * 0.5);
        this.gravity = 0.04f;

        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
    }

    @Override
    public void tick() {
        super.tick();
        // Замедление
        this.xd *= 0.92f;
        this.yd *= 0.92f;
        this.zd *= 0.92f;
        // Постепенное исчезновение
        if (this.age > this.lifetime * 0.5f) {
            this.alpha = 0.9f * (1.0f - (float)(this.age - this.lifetime * 0.5) / (this.lifetime * 0.5f));
        }
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Factory(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                        double x, double y, double z,
                                        double vx, double vy, double vz) {
            ExplosionDustParticle p = new ExplosionDustParticle(level, x, y, z, vx, vy, vz);
            p.pickSprite(sprites);
            return p;
        }
    }
}
